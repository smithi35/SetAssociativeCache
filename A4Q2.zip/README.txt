Simply execute the program. It knows which file to access for the input data
and will do so eight times for each Set Associative Cache, and print out the hit rates for each.

To compile, use javac for the one file of source code. I used openjdk 8
